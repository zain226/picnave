<footer id="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong><span>Haseeb Abbas</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Designed by <a href="https://www.infinitysolutionz.com/">Infinity Solutionz</a>
        </div>
    </div>
</footer>
